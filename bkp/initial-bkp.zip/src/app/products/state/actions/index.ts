import * as ProductPageActions from './product-page.actions';
import * as ProductApiActions from './product-api.actions';

export { ProductPageActions, ProductApiActions };
