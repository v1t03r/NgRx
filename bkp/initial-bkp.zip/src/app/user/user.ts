/* Defines the user entity */
export interface User {
    id: number;
    userName: string;
    isAdmin: boolean;
}
