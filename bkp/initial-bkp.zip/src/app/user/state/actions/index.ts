import * as UserPageActions from './user-page.actions';

export { UserPageActions };
