/* NgRx */
import { createAction } from '@ngrx/store';

export const maskUserName = createAction(
  '[User Page] Mask User Name'
);
